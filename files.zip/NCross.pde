// NCross now delegates entirely to drawNodesWithState in NSpoke.pde
// (kept as separate file for clarity and future divergence)

// drawNCross is defined in NSpoke.pde
