// ── NSpoke / NCross unified renderer ─────────────────────────────────────────
//
// Hit target stateIdx encoding:
//   0..N          direct indices into the active framework's state array
//   >= NESTED_BASE  encoded as: NESTED_BASE + ownerHitIdx*MAX_CHILDREN + childLocalIdx
//     ownerHitIdx  = the hitTargets[] index of the parent node
//     childLocalIdx = 0 for hub-proxy, 1..n for satellites
//
// This lets Inspector decode: "which NodeState owns this child, and which child?"
// ─────────────────────────────────────────────────────────────────────────────

final int NESTED_BASE    = 100000;
final int MAX_CHILDREN   = 64;

void drawNSpoke(int n) {
  if (spokeState == null || spokeState.length < n+1) return;
  drawNodesWithState(n, spokeState, spokeOrbitR, SLOT_SPOKE, 0);
}

void drawNCross(int n) {
  if (crossState == null || crossState.length < n+1) return;
  drawNodesWithState(n, crossState, crossOrbitR, SLOT_CROSS, 0);
}

// Draw hub + n satellites. diagramType controls whether arrows are drawn.
void drawNodesWithState(int n, NodeState[] states, float orbitR,
                        int diagramType, int stateOffset) {
  NodeState hub = states[0];
  styledOrbit(0, 0, orbitR, hub);

  for (int i = 0; i < n; i++) {
    NodeState ns = states[i+1];
    float sx =  orbitR * sin(ns.ang);
    float sy = -orbitR * cos(ns.ang);

    if (diagramType == SLOT_CROSS) {
      float off=7, aHead=7;
      float dx=sin(ns.ang), dy=-cos(ns.ang);
      float px=-dy*off, py=dx*off;
      float gapC=hub.r+4, gapS=ns.r+4;
      stroke(FG); strokeWeight(1.3);
      arrow(dx*gapC+px, dy*gapC+py, sx-dx*gapS+px, sy-dy*gapS+py, aHead);
      arrow(sx-dx*gapS-px, sy-dy*gapS-py, dx*gapC-px, dy*gapC-py, aHead);
    }

    int hitIdx = hitCount;   // index this node will have in hitTargets
    registerHitTarget(sx, sy, ns.r, stateOffset + i+1);

    if (ns.isHub()) drawSubDiagram(ns, sx, sy, hitIdx);
    else            styledNode(sx, sy, ns, "label");
  }

  // Hub last
  registerHitTarget(0, 0, hub.r, stateOffset + 0);
  styledNode(0, 0, hub, "");
}

// Draw a node's sub-diagram. ownerHitIdx is this node's index in hitTargets[].
void drawSubDiagram(NodeState ns, float cx, float cy, int ownerHitIdx) {
  float sc = ns.r / ns.subOrbitR;
  int   n  = ns.numSatellites();

  // Draw node itself as the hub visual
  styledNode(cx, cy, ns, "");

  // Draw orbit ring
  pushMatrix();
    translate(cx, cy);
    scale(sc);
    styledOrbit(0, 0, ns.subOrbitR, ns);

    for (int i = 0; i < n; i++) {
      NodeState child = ns.children[i+1];
      float sx =  ns.subOrbitR * sin(child.ang);
      float sy = -ns.subOrbitR * cos(child.ang);

      if (ns.subType == SLOT_CROSS) {
        float off=7, aHead=7;
        float dx=sin(child.ang), dy=-cos(child.ang);
        float px=-dy*off, py=dx*off;
        float gapC=ns.children[0].r+4, gapS=child.r+4;
        stroke(FG); strokeWeight(1.3);
        arrow(dx*gapC+px, dy*gapC+py, sx-dx*gapS+px, sy-dy*gapS+py, aHead);
        arrow(sx-dx*gapS-px, sy-dy*gapS-py, dx*gapC-px, dy*gapC-py, aHead);
      }

      // Encode: owner's hit index + child's local index
      int childStIdx = NESTED_BASE + ownerHitIdx * MAX_CHILDREN + (i+1);
      int childHitIdx = hitCount;
      registerHitTarget(sx, sy, child.r, childStIdx);

      if (child.isHub()) drawSubDiagram(child, sx, sy, childHitIdx);
      else               styledNode(sx, sy, child, "label");
    }
  popMatrix();

  // Correct child hit target positions to screen space
  int startHit = hitCount - n;
  for (int i = 0; i < n; i++) {
    NodeState child = ns.children[i+1];
    float lx =  ns.subOrbitR * sin(child.ang);
    float ly = -ns.subOrbitR * cos(child.ang);
    hitTargets[startHit+i][0] = inspectorCX + cx + lx*sc;
    hitTargets[startHit+i][1] = inspectorCY + cy + ly*sc;
    hitTargets[startHit+i][2] = child.r * sc;
  }
}
