// ── Nested Level framework ────────────────────────────────────────────────────
// Starts as a single hub node. Users add satellites via sidebar.
// Each satellite can itself be promoted to a sub-diagram — infinitely deep.
// ─────────────────────────────────────────────────────────────────────────────

final int SLOT_BASE      = 1000;
final int MAX_SLOT_NODES = 32;

void drawTwoLevel(int nInner, int nOuter) {
  if (twoState == null || twoState.length < 1) return;
  NodeState hub = twoState[0];

  if (!hub.isHub()) {
    // Plain hub — just draw the single node centered
    registerHitTarget(0, 0, hub.r, 0);
    styledNode(0, 0, hub, "");
  } else {
    // Hub has been promoted — draw orbit + satellites + hub at center
    float screenOrbitR = hub.subOrbitR * hub.subScale;
    styledOrbit(0, 0, screenOrbitR, hub);

    int n = hub.numSatellites();
    for (int i = 0; i < n; i++) {
      NodeState child = hub.children[i+1];
      float sx =  screenOrbitR * sin(child.ang);
      float sy = -screenOrbitR * cos(child.ang);

      if (hub.subType == SLOT_CROSS) {
        float off=7, aHead=7;
        float dx=sin(child.ang), dy=-cos(child.ang);
        float px=-dy*off, py=dx*off;
        float gapC=hub.r+4, gapS=child.r*hub.subScale+4;
        stroke(FG); strokeWeight(1.3);
        arrow(dx*gapC+px,dy*gapC+py,sx-dx*gapS+px,sy-dy*gapS+py,aHead);
        arrow(sx-dx*gapS-px,sy-dy*gapS-py,dx*gapC-px,dy*gapC-py,aHead);
      }

      // Register hit target — encode as nested child of hub (hit index = next slot)
      int hubHitIdx = hitCount; // will be registered after children loop — store placeholder
      int childStIdx = NESTED_BASE + 0 * MAX_CHILDREN + (i+1);
      // We'll correct hubHitIdx after registering hub below
      // For now use 0 as placeholder — corrected after hub registration
      registerHitTarget(sx, sy, child.r * hub.subScale, childStIdx);

      if (child.isHub()) {
        drawSubDiagram(child, sx, sy, hitCount-1);
      } else {
        styledNode(sx, sy, child, "label");
      }
    }

    // Hub drawn last — on top
    int hubHitIdx = hitCount;
    registerHitTarget(0, 0, hub.r, 0);
    styledNode(0, 0, hub, "");

    // Fix child stateIdx encoding now that we know hubHitIdx
    // Children were registered before hub, so they are at hitCount-n-1 .. hitCount-2
    int startHit = hubHitIdx - n;
    for (int i = 0; i < n; i++) {
      hitTargets[startHit+i][3] = NESTED_BASE + hubHitIdx * MAX_CHILDREN + (i+1);
    }
  }
}
