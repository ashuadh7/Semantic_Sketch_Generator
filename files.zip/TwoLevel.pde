// ── Two-level nested ──────────────────────────────────────────────────────────
// Outer slots now read sub-diagram config from each node's own .subType /
// .children fields — no more global slotStates[] / slotTypes[] arrays.
// ─────────────────────────────────────────────────────────────────────────────

// Legacy constants kept for Inspector decode compatibility
final int SLOT_BASE      = 1000;
final int MAX_SLOT_NODES = 32;

void drawTwoLevel(int nInner, int nOuter) {
  if (twoState == null || twoState.length < 1+nInner+nOuter) return;

  NodeState hub   = twoState[0];
  float     off   = 6;
  float     aHead = 7;

  // Enclosing circle
  stroke(hub.orbitCol); strokeWeight(2); noFill();
  if (hub.orbitDashed) dashedCircle(0, 0, twoOuterOrbitR, 8, 6);
  else ellipse(0, 0, twoOuterOrbitR*2, twoOuterOrbitR*2);

  // ── Outer slots ─────────────────────────────────────────────────────────────
  for (int i = 0; i < nOuter; i++) {
    NodeState ns = twoState[1+nInner+i];
    float ox =  twoOuterOrbitR * sin(ns.ang);
    float oy = -twoOuterOrbitR * cos(ns.ang);

    int hitIdx = hitCount;
    registerHitTarget(ox, oy, ns.r, 1+nInner+i);

    if (ns.isHub()) drawSubDiagram(ns, ox, oy, hitIdx);
    else            styledNode(ox, oy, ns, "label");
  }

  // ── Inner ring ───────────────────────────────────────────────────────────────
  styledOrbit(0, 0, twoInnerOrbitR, hub);

  for (int i = 0; i < nInner; i++) {
    NodeState ns = twoState[1+i];
    float sx =  twoInnerOrbitR * sin(ns.ang);
    float sy = -twoInnerOrbitR * cos(ns.ang);

    float dx=sin(ns.ang), dy=-cos(ns.ang);
    float px=-dy*off, py=dx*off;
    float gapC=hub.r+4, gapS=ns.r+4;

    int hitIdx = hitCount;
    registerHitTarget(sx, sy, ns.r, 1+i);
    styledNode(sx, sy, ns, "label");

    stroke(FG); strokeWeight(1.4);
    arrow(dx*gapC+px, dy*gapC+py, sx-dx*gapS+px, sy-dy*gapS+py, aHead);
    arrow(sx-dx*gapS-px, sy-dy*gapS-py, dx*gapC-px, dy*gapC-py, aHead);

    if (ns.isHub()) drawSubDiagram(ns, sx, sy, hitIdx);
  }

  // Hub last
  registerHitTarget(0, 0, hub.r, 0);
  styledNode(0, 0, hub, "label");
}
