// ── Inspector + Sidebar ───────────────────────────────────────────────────────

int   selectedNode = -1;
float inspectorCX, inspectorCY;

float[][] hitTargets;
int       hitCount;

final int SB_W   = 220;
final int SB_PAD = 14;
final color SB_BG   = color(248);
final color SB_LINE = color(210);

// ── Text editing ──────────────────────────────────────────────────────────────
boolean editingLabel = false;
String  editBuffer   = "";

void activateLabelEdit(NodeState ns) { editingLabel=true; editBuffer=ns.label; }
void commitLabelEdit(NodeState ns)   { if(ns!=null&&editBuffer.length()>0) ns.label=editBuffer; editingLabel=false; }

// ── Hit target registry ───────────────────────────────────────────────────────
void resetHitTargets(int maxNodes) {
  hitTargets = new float[maxNodes][4]; hitCount = 0;
}

void registerHitTarget(float wx, float wy, float r, int stateIdx) {
  if (hitCount >= hitTargets.length) return;
  hitTargets[hitCount][0] = inspectorCX + wx;
  hitTargets[hitCount][1] = inspectorCY + wy;
  hitTargets[hitCount][2] = r;
  hitTargets[hitCount][3] = stateIdx;
  hitCount++;
}

int selectedStateIdx() {
  if (selectedNode<0||selectedNode>=hitCount) return -1;
  return (int)hitTargets[selectedNode][3];
}

// Decode stateIdx into the actual NodeState.
// Returns null if not found.
// Also fills selectedOwner / selectedLocalIdx as side effects.
NodeState selectedOwner  = null;   // the NodeState array owner (null = top-level array)
int       selectedLocalIdx = -1;   // index within owner's children[] or state array

NodeState selectedNodeState() {
  selectedOwner    = null;
  selectedLocalIdx = -1;
  int stateIdx = selectedStateIdx();
  if (stateIdx < 0) return null;

  // Nested child: NESTED_BASE + ownerHitIdx*MAX_CHILDREN + localIdx
  if (stateIdx >= NESTED_BASE) {
    int rel        = stateIdx - NESTED_BASE;
    int ownerHit   = rel / MAX_CHILDREN;
    int localIdx   = rel % MAX_CHILDREN;
    // Resolve owner NodeState from its hit record
    if (ownerHit < 0 || ownerHit >= hitCount) return null;
    NodeState owner = resolveHitToNode((int)hitTargets[ownerHit][3]);
    if (owner == null || owner.children == null || localIdx >= owner.children.length) return null;
    selectedOwner    = owner;
    selectedLocalIdx = localIdx;
    return owner.children[localIdx];
  }

  // Top-level node
  NodeState[] states = activeStates();
  if (states == null || stateIdx >= states.length) return null;
  selectedLocalIdx = stateIdx;
  return states[stateIdx];
}

// Resolve a top-level stateIdx to the NodeState (no nesting)
NodeState resolveHitToNode(int stateIdx) {
  if (stateIdx >= NESTED_BASE) {
    int rel      = stateIdx - NESTED_BASE;
    int ownerHit = rel / MAX_CHILDREN;
    int localIdx = rel % MAX_CHILDREN;
    if (ownerHit < 0 || ownerHit >= hitCount) return null;
    NodeState owner = resolveHitToNode((int)hitTargets[ownerHit][3]);
    if (owner==null||owner.children==null||localIdx>=owner.children.length) return null;
    return owner.children[localIdx];
  }
  NodeState[] states = activeStates();
  if (states==null||stateIdx>=states.length) return null;
  return states[stateIdx];
}

boolean selectedIsTopLevelHub() {
  // Is the selected node the hub (index 0) of its containing framework?
  return selectedOwner==null && selectedLocalIdx==0;
}

boolean selectedIsHub() {
  // Does the selected node own a sub-diagram?
  NodeState ns = selectedNodeState();
  return ns != null && ns.isHub();
}

// Is the selected node a satellite (not index-0 of any array)?
boolean selectedIsSatellite() {
  selectedNodeState();  // fills selectedLocalIdx
  return selectedLocalIdx > 0;
}

float hubOrbitR() {
  NodeState ns = selectedNodeState();
  if (ns == null) return 0;
  if (ns.isHub()) return ns.subOrbitR;
  if (selectedOwner == null && selectedLocalIdx == 0) {
    // Top-level hub
    switch(activeFrame) {
      case 0: return spokeOrbitR;
      case 1: return crossOrbitR;
      case 2: return twoInnerOrbitR;
    }
  }
  return 0;
}

void drawSelectionRing() {
  if (selectedNode<0||selectedNode>=hitCount) return;
  float sx=hitTargets[selectedNode][0], sy=hitTargets[selectedNode][1];
  float r =hitTargets[selectedNode][2];
  noFill(); stroke(60,120,220); strokeWeight(2.5);
  ellipse(sx, sy, (r+8)*2, (r+8)*2);
}

void drawHUD() {
  fill(MUTED); noStroke(); textSize(11); textAlign(CENTER,BOTTOM);
  if (selectedNodeState()==null) {
    text("Click a node to select  ·  [ ] radius  ·  , . orbit (hub)  ·  Tab  ·  Esc",
         (width-SB_W)/2.0, height-8); return;
  }
  if (editingLabel) {
    fill(color(30,80,180));
    text("Editing label — Enter to confirm  ·  Esc to cancel",
         (width-SB_W)/2.0, height-8); return;
  }
  NodeState ns = selectedNodeState();
  fill(color(30,80,180));
  float orb = hubOrbitR();
  String hud = "● "+ns.label
    +(orb>0?"   orbit="+nf(orb,0,1):"")
    +"  [ ] resize"+(orb>0?"  , . orbit":"")+"  Tab  Esc";
  text(hud, (width-SB_W)/2.0, height-8);
}

int pickNode(float mx, float my) {
  for (int i=0; i<hitCount; i++) {
    float dx=mx-hitTargets[i][0], dy=my-hitTargets[i][1];
    if (dx*dx+dy*dy <= hitTargets[i][2]*hitTargets[i][2]) return i;
  }
  return -1;
}

// ── Sidebar ───────────────────────────────────────────────────────────────────
float sbX() { return width-SB_W; }

void drawSidebar() {
  float x = sbX();
  fill(SB_BG); noStroke(); rect(x, 0, SB_W, height);
  stroke(SB_LINE); strokeWeight(1); line(x, 0, x, height);

  NodeState ns = selectedNodeState();
  if (ns==null) {
    fill(MUTED); noStroke(); textSize(12); textAlign(CENTER,CENTER);
    text("Select a node\nto edit properties", x+SB_W/2.0, height/2.0); return;
  }

  boolean isSatellite = selectedIsSatellite();
  boolean hasChildren = ns.isHub();
  boolean isTopHub    = (selectedOwner==null && selectedLocalIdx==0);

  float y = 20;

  // Title
  fill(FG); noStroke(); textSize(13); textAlign(LEFT,TOP);
  text(ns.label, x+SB_PAD, y);
  fill(MUTED); textSize(10);
  text(isTopHub ? "framework hub" : hasChildren ? "hub node" : "satellite", x+SB_PAD, y+16);
  y += 38; sbDivider(y); y += 12;

  // ── Label ─────────────────────────────────────────────────────────────────
  y = sbSectionLabel("Label", x, y);
  boolean fieldActive = editingLabel;
  fill(fieldActive?color(230,240,255):color(238));
  stroke(fieldActive?color(80,140,210):color(200));
  strokeWeight(fieldActive?1.8:1);
  rect(x+SB_PAD, y, SB_W-SB_PAD*2, 24, 4);
  String displayed = fieldActive ? editBuffer : ns.label;
  String cursor = (fieldActive && frameCount%60<30) ? "|" : "";
  fill(FG); noStroke(); textSize(12); textAlign(LEFT,CENTER);
  text(displayed+cursor, x+SB_PAD+6, y+12);
  sbRegisterClick(x+SB_PAD, y, SB_W-SB_PAD*2, 24, "LABEL_FIELD");
  y += 32; sbDivider(y); y += 12;

  // ── Node appearance ────────────────────────────────────────────────────────
  y = sbSectionLabel("Node", x, y);
  y = sbColorRow("Fill", ns.fillCol, "NODE_COLOR", x, y);
  y = sbAlphaSlider("Alpha (overlay)", ns.alpha, "NODE_ALPHA", x, y);
  y = sbShapeRow(ns.shapeType, x, y);
  y += 4; sbDivider(y); y += 12;

  // ── Image ─────────────────────────────────────────────────────────────────
  y = sbSectionLabel("Image", x, y);
  float previewSize=60;
  float previewX = x+SB_W/2.0-previewSize/2.0;
  if (ns.img!=null) {
    ns.rebuildMask((int)previewSize);
    if (ns.cropToShape && ns.imgMasked!=null) {
      image(ns.imgMasked, previewX, y, previewSize, previewSize);
    } else {
      float aspect=(float)ns.img.width/ns.img.height;
      float pH=previewSize/sqrt(aspect*aspect+1), pW=pH*aspect;
      image(ns.img, previewX+(previewSize-pW)/2, y+(previewSize-pH)/2, pW, pH);
    }
    stroke(200); strokeWeight(1); noFill();
    if (ns.cropToShape) ellipse(previewX+previewSize/2, y+previewSize/2, previewSize, previewSize);
    else rect(previewX, y, previewSize, previewSize, 4);
  } else {
    fill(230); stroke(200); strokeWeight(1);
    rect(previewX, y, previewSize, previewSize, 6);
    fill(MUTED); noStroke(); textSize(10); textAlign(CENTER,CENTER);
    text("no image", previewX+previewSize/2, y+previewSize/2);
  }
  y += previewSize+8;
  float btnW2=(SB_W-SB_PAD*2-4)/2.0;
  sbButton("Add image…", x+SB_PAD,           y, btnW2, 24, "IMG_ADD",    false);
  sbButton("Remove",     x+SB_PAD+btnW2+4,   y, btnW2, 24, "IMG_REMOVE", ns.img==null);
  y += 32;
  y = sbToggle("Crop to shape", ns.cropToShape, "IMG_CROP", x, y, ns.img==null);
  y += 4; sbDivider(y); y += 12;

  // ── Orbit (only for nodes that own children, or top-level hubs) ───────────
  float orb = hubOrbitR();
  boolean showOrbit = (hasChildren || isTopHub) && orb > 0;
  y = sbSectionLabel("Orbit", x, y, showOrbit);
  if (showOrbit) {
    y = sbColorRow("Color", ns.orbitCol, "ORBIT_COLOR", x, y);
    y = sbOrbitTypeRow(ns.orbitDashed, x, y);
  } else {
    fill(MUTED); noStroke(); textSize(11); textAlign(LEFT,TOP);
    text("(select hub to edit orbit)", x+SB_PAD, y); y += 20;
  }
  y += 4; sbDivider(y); y += 12;

  // ── Diagram / nesting ─────────────────────────────────────────────────────
  y = sbSectionLabel("Nesting", x, y);

  if (!hasChildren) {
    // Not yet a hub — show promote buttons
    fill(MUTED); noStroke(); textSize(11); textAlign(LEFT,TOP);
    text("Expand node to hub:", x+SB_PAD, y); y += 18;
    float bw3=(SB_W-SB_PAD*2-8)/2.0;
    sbButton("+ Cross",  x+SB_PAD,         y, bw3, 24, "PROMOTE_CROSS", false);
    sbButton("+ Spoke",  x+SB_PAD+bw3+8,   y, bw3, 24, "PROMOTE_SPOKE", false);
    y += 32;
  } else {
    // Already a hub — show type, +/- satellites, demote
    fill(MUTED); noStroke(); textSize(11); textAlign(LEFT,TOP);
    text("Type: " + (ns.subType==SLOT_CROSS?"Cross":"Spoke")
         + "   Satellites: " + ns.numSatellites(), x+SB_PAD, y); y += 18;

    float bw3=(SB_W-SB_PAD*2-8)/3.0;
    sbButton("− sat",    x+SB_PAD,           y, bw3, 24, "SAT_REMOVE", ns.numSatellites()<=1);
    sbButton("+ sat",    x+SB_PAD+bw3+4,     y, bw3, 24, "SAT_ADD",    false);
    sbButton("Flatten",  x+SB_PAD+(bw3+4)*2, y, bw3, 24, "DEMOTE",     false);
    y += 32;

    // Switch type
    float bw2=(SB_W-SB_PAD*2-4)/2.0;
    boolean isCross=(ns.subType==SLOT_CROSS);
    sbButton("→ Cross", x+SB_PAD,        y, bw2, 22, "SWITCH_CROSS", isCross);
    sbButton("→ Spoke", x+SB_PAD+bw2+4, y, bw2, 22, "SWITCH_SPOKE", !isCross);
    y += 30;
  }

  // Delete satellite (not for top-level hub or framework hub)
  if (isSatellite && !isTopHub) {
    y += 4; sbDivider(y); y += 12;
    sbButton("Delete this node", x+SB_PAD, y, SB_W-SB_PAD*2, 24, "DELETE_NODE", false);
  }
}

// ── Sidebar component helpers ─────────────────────────────────────────────────
void sbDivider(float y) { stroke(SB_LINE); strokeWeight(1); line(sbX(),y,sbX()+SB_W,y); }

float sbSectionLabel(String l, float x, float y) { return sbSectionLabel(l,x,y,true); }
float sbSectionLabel(String l, float x, float y, boolean active) {
  fill(active?color(80,130,200):MUTED); noStroke(); textSize(10); textAlign(LEFT,TOP);
  text(l.toUpperCase(), x+SB_PAD, y); return y+18;
}

float sbColorRow(String label, color current, String tag, float x, float y) {
  fill(MUTED); noStroke(); textSize(11); textAlign(LEFT,TOP); text(label,x+SB_PAD,y);
  color[] cols={color(200,70,70),color(160),color(70,170,100)};
  float sw=22,gap=6,startX=x+SB_W-SB_PAD-(sw+gap)*3+gap;
  for (int i=0;i<3;i++) {
    float sx=startX+i*(sw+gap);
    boolean sel=(int)red(current)==(int)red(cols[i])&&(int)green(current)==(int)green(cols[i])&&(int)blue(current)==(int)blue(cols[i]);
    fill(cols[i]); stroke(sel?color(40,80,180):color(180)); strokeWeight(sel?2.5:1);
    rect(sx,y-1,sw,sw,4); sbRegisterClick(sx,y-1,sw,sw,tag+"_"+i);
  }
  return y+sw+6;
}

float sbAlphaSlider(String label, int current, String tag, float x, float y) {
  fill(MUTED); noStroke(); textSize(11); textAlign(LEFT,TOP); text(label,x+SB_PAD,y);
  fill(FG); textAlign(RIGHT,TOP); text(current,x+SB_W-SB_PAD,y); y+=16;
  float tx=x+SB_PAD,tw=SB_W-SB_PAD*2,th=6;
  fill(210); noStroke(); rect(tx,y,tw,th,3);
  fill(100,140,220); rect(tx,y,tw*(current/255.0),th,3);
  fill(255); stroke(150); strokeWeight(1.5); ellipse(tx+tw*(current/255.0),y+th/2,12,12);
  sbRegisterClick(tx,y-16,tw,th+20,tag); return y+th+12;
}

float sbShapeRow(int current, float x, float y) {
  fill(MUTED); noStroke(); textSize(11); textAlign(LEFT,TOP); text("Shape",x+SB_PAD,y); y+=16;
  String[] lbs={"●","▬","◆"}; int[] types={SHAPE_CIRCLE,SHAPE_RECT,SHAPE_DIAMOND};
  float bw=(SB_W-SB_PAD*2-8)/3.0;
  for (int i=0;i<3;i++) {
    float bx=x+SB_PAD+i*(bw+4); boolean sel=(current==types[i]);
    fill(sel?color(210,230,255):color(235)); stroke(sel?color(80,140,210):color(200)); strokeWeight(sel?1.8:1);
    rect(bx,y,bw,26,5); fill(sel?color(30,80,160):FG); noStroke(); textSize(14); textAlign(CENTER,CENTER);
    text(lbs[i],bx+bw/2,y+13); sbRegisterClick(bx,y,bw,26,"SHAPE_"+i);
  }
  return y+32;
}

float sbOrbitTypeRow(boolean dashed, float x, float y) {
  fill(MUTED); noStroke(); textSize(11); textAlign(LEFT,TOP); text("Orbit line",x+SB_PAD,y); y+=16;
  String[] lbs={"- - -","───"}; boolean[] vals={true,false};
  float bw=(SB_W-SB_PAD*2-4)/2.0;
  for (int i=0;i<2;i++) {
    float bx=x+SB_PAD+i*(bw+4); boolean sel=(dashed==vals[i]);
    fill(sel?color(210,230,255):color(235)); stroke(sel?color(80,140,210):color(200)); strokeWeight(sel?1.8:1);
    rect(bx,y,bw,26,5); fill(sel?color(30,80,160):FG); noStroke(); textSize(11); textAlign(CENTER,CENTER);
    text(lbs[i],bx+bw/2,y+13); sbRegisterClick(bx,y,bw,26,"ORBIT_TYPE_"+i);
  }
  return y+32;
}

float sbToggle(String label, boolean state, String tag, float x, float y, boolean disabled) {
  fill(disabled?color(200):MUTED); noStroke(); textSize(11); textAlign(LEFT,CENTER);
  text(label,x+SB_PAD,y+10);
  float tx=x+SB_W-SB_PAD-36,ty=y+2;
  fill(disabled?color(220):(state?color(80,160,100):color(190))); noStroke(); rect(tx,ty,36,16,8);
  fill(255); noStroke(); ellipse(state?tx+26:tx+10,ty+8,12,12);
  if (!disabled) sbRegisterClick(tx,ty,36,16,tag); return y+26;
}

void sbButton(String label, float x, float y, float w, float h, String tag, boolean disabled) {
  fill(disabled?color(225):color(235)); stroke(disabled?color(210):color(190)); strokeWeight(1);
  rect(x,y,w,h,4); fill(disabled?color(180):FG); noStroke(); textSize(11); textAlign(CENTER,CENTER);
  text(label,x+w/2,y+h/2); if (!disabled) sbRegisterClick(x,y,w,h,tag);
}

// ── Click zone registry ───────────────────────────────────────────────────────
final int MAX_SB_ZONES=100;
float[][] sbZones=new float[MAX_SB_ZONES][4];
String[]  sbZoneTags=new String[MAX_SB_ZONES];
int       sbZoneCount=0;
void sbResetZones() { sbZoneCount=0; }
void sbRegisterClick(float x,float y,float w,float h,String tag) {
  if (sbZoneCount>=MAX_SB_ZONES) return;
  sbZones[sbZoneCount][0]=x; sbZones[sbZoneCount][1]=y;
  sbZones[sbZoneCount][2]=w; sbZones[sbZoneCount][3]=h;
  sbZoneTags[sbZoneCount]=tag; sbZoneCount++;
}
String sbPickZone(float mx,float my) {
  for (int i=0;i<sbZoneCount;i++)
    if (mx>=sbZones[i][0]&&mx<=sbZones[i][0]+sbZones[i][2]&&
        my>=sbZones[i][1]&&my<=sbZones[i][1]+sbZones[i][3]) return sbZoneTags[i];
  return null;
}

void sbHandleClick(String tag, float mx, float my) {
  if (tag==null) return;
  NodeState ns = selectedNodeState();
  if (ns==null) return;
  color[] cols={color(200,70,70),color(160),color(70,170,100)};

  if      (tag.equals("LABEL_FIELD"))   { activateLabelEdit(ns); }
  else if (tag.startsWith("NODE_COLOR_"))  { ns.fillCol=cols[int(tag.charAt(tag.length()-1))-48]; }
  else if (tag.startsWith("ORBIT_COLOR_")) { ns.orbitCol=cols[int(tag.charAt(tag.length()-1))-48]; }
  else if (tag.startsWith("SHAPE_"))    { ns.shapeType=int(tag.charAt(tag.length()-1))-48; ns.invalidateCache(); }
  else if (tag.startsWith("ORBIT_TYPE_")) { ns.orbitDashed=(int(tag.charAt(tag.length()-1))-48==0); }
  else if (tag.equals("NODE_ALPHA"))    { float tx=sbX()+SB_PAD,tw=SB_W-SB_PAD*2; ns.alpha=(int)constrain(map(mx,tx,tx+tw,0,255),0,255); }
  else if (tag.equals("IMG_ADD"))       { pendingImageNode=ns; selectInput("Select an image","imageSelected"); }
  else if (tag.equals("IMG_REMOVE"))    { ns.img=null; ns.invalidateCache(); }
  else if (tag.equals("IMG_CROP"))      { ns.cropToShape=!ns.cropToShape; ns.invalidateCache(); }
  else if (tag.equals("PROMOTE_CROSS")) { ns.promote(SLOT_CROSS, 3); }
  else if (tag.equals("PROMOTE_SPOKE")) { ns.promote(SLOT_SPOKE, 3); }
  else if (tag.equals("DEMOTE"))        { ns.demote(); }
  else if (tag.equals("SAT_ADD"))       { ns.addSatellite(); }
  else if (tag.equals("SAT_REMOVE"))    { ns.removeSatellite(ns.numSatellites()); }
  else if (tag.equals("SWITCH_CROSS"))  { ns.subType=SLOT_CROSS; }
  else if (tag.equals("SWITCH_SPOKE"))  { ns.subType=SLOT_SPOKE; }
  else if (tag.equals("DELETE_NODE"))   { deleteSatellite(); }
}

// Delete the currently selected satellite from its parent
void deleteSatellite() {
  selectedNodeState();  // refresh selectedOwner / selectedLocalIdx
  if (selectedLocalIdx <= 0) return;

  if (selectedOwner != null) {
    // Child of a sub-diagram
    selectedOwner.removeSatellite(selectedLocalIdx);
  } else {
    // Top-level satellite — remove from active framework state array
    NodeState[] states = activeStates();
    if (states == null || selectedLocalIdx >= states.length) return;
    NodeState[] next = new NodeState[states.length - 1];
    int k = 0;
    for (int i = 0; i < states.length; i++)
      if (i != selectedLocalIdx) next[k++] = states[i];
    setActiveStates(next);
  }
  selectedNode = -1;
}

// Replace the active framework's state array
void setActiveStates(NodeState[] next) {
  switch (activeFrame) {
    case 0: spokeState = next; break;
    case 1: crossState = next; break;
    case 2: twoState   = next; break;
  }
}

boolean sbDragging=false; String sbDragTag=null;
void sbMousePressed(float mx,float my) { String tag=sbPickZone(mx,my); sbDragTag=tag; sbDragging=true; sbHandleClick(tag,mx,my); }
void sbMouseDragged(float mx,float my) {
  if (!sbDragging||sbDragTag==null) return;
  if (sbDragTag.equals("NODE_ALPHA")) {
    NodeState ns=selectedNodeState(); if(ns==null) return;
    float tx=sbX()+SB_PAD,tw=SB_W-SB_PAD*2;
    ns.alpha=(int)constrain(map(mx,tx,tx+tw,0,255),0,255);
  }
}
void sbMouseReleased() { sbDragging=false; sbDragTag=null; }

boolean sbKeyPressed() {
  if (!editingLabel) return false;
  NodeState ns=selectedNodeState();
  if (key==ENTER||key==RETURN) { commitLabelEdit(ns); return true; }
  if (key==ESC) { editingLabel=false; key=0; return true; }
  if (key==BACKSPACE) { if(editBuffer.length()>0) editBuffer=editBuffer.substring(0,editBuffer.length()-1); return true; }
  if (key>=32&&key<127) { editBuffer+=key; return true; }
  return true;
}
