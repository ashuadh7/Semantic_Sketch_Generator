// ── NodeState ─────────────────────────────────────────────────────────────────

final int SHAPE_CIRCLE  = 0;
final int SHAPE_RECT    = 1;
final int SHAPE_DIAMOND = 2;

class NodeState {
  String  label;
  float   r;
  float   ang;

  // Visual style
  color   fillCol   = color(245);
  int     alpha     = 255;
  int     shapeType = SHAPE_CIRCLE;

  // Orbit style (meaningful when this node owns children)
  color   orbitCol    = color(180);
  boolean orbitDashed = true;

  // Image
  PImage  img           = null;
  boolean cropToShape   = true;
  PImage  imgMasked     = null;
  int     imgCacheSize  = -1;
  int     imgCacheShape = -1;

  // ── Sub-diagram (recursive) ───────────────────────────────────────────────
  // SLOT_PLAIN = leaf node. SLOT_CROSS / SLOT_SPOKE = hub with children.
  int         subType   = SLOT_PLAIN;
  float       subOrbitR = 80.0;
  NodeState[] children  = null;   // [0]=hub proxy (this node), [1..n]=satellites
  // Note: children[0] is a thin proxy — it mirrors this node's label/style
  // so sub-diagram renderers can read hub appearance from children[0].

  NodeState(String label, float r, float ang) {
    this.label = label;
    this.r     = r;
    this.ang   = ang;
  }

  boolean isHub() { return subType != SLOT_PLAIN && children != null; }
  int     numSatellites() { return (children == null) ? 0 : children.length - 1; }

  // Promote this node to a hub with n satellites of the given type.
  // The node itself becomes the center; new satellites orbit around it.
  void promote(int type, int n) {
    subType  = type;
    children = new NodeState[n + 1];
    // children[0] is the hub proxy — mirrors this node
    children[0] = new NodeState(label, r * 0.9, 0);
    children[0].fillCol   = fillCol;
    children[0].shapeType = shapeType;
    for (int i = 0; i < n; i++) {
      float a = (type == SLOT_SPOKE)
        ? radians(180 + i * (360.0 / n))
        : radians(i * (360.0 / n));
      float rSat = min(r * 0.55, (TWO_PI * subOrbitR / n) * 0.36);
      children[i+1] = new NodeState("Node " + (char)('A' + i % 26), max(10, rSat), a);
    }
  }

  // Revert to plain leaf node, discarding all children.
  void demote() {
    subType  = SLOT_PLAIN;
    children = null;
  }

  // Add one satellite at the end.
  void addSatellite() {
    if (children == null) return;
    int n = children.length;   // includes hub at [0]
    NodeState[] next = new NodeState[n + 1];
    for (int i = 0; i < n; i++) next[i] = children[i];
    int   idx = n - 1;         // new satellite index (0-based among satellites)
    float a   = (subType == SLOT_SPOKE)
      ? radians(180 + idx * (360.0 / idx))
      : radians(idx * (360.0 / idx));
    // Recompute all angles evenly
    int totalSats = n;   // n-1 old + 1 new = n satellites total after add
    for (int i = 1; i < n; i++) {
      next[i].ang = (subType == SLOT_SPOKE)
        ? radians(180 + (i-1) * (360.0 / totalSats))
        : radians((i-1) * (360.0 / totalSats));
    }
    float rSat = min(children[0].r * 0.55,
                     (TWO_PI * subOrbitR / totalSats) * 0.36);
    next[n] = new NodeState("Node " + (char)('A' + (n-1) % 26), max(10, rSat), 0);
    next[n].ang = (subType == SLOT_SPOKE)
      ? radians(180 + (n-1) * (360.0 / totalSats))
      : radians((n-1) * (360.0 / totalSats));
    children = next;
    recomputeAngles();
  }

  // Remove satellite at index i (1-based in children[]).
  void removeSatellite(int i) {
    if (children == null || i < 1 || i >= children.length) return;
    if (children.length <= 2) { demote(); return; }  // last satellite → demote
    NodeState[] next = new NodeState[children.length - 1];
    next[0] = children[0];
    int k = 1;
    for (int j = 1; j < children.length; j++) {
      if (j != i) next[k++] = children[j];
    }
    children = next;
    recomputeAngles();
  }

  // Recompute angles evenly after add/remove.
  void recomputeAngles() {
    if (children == null) return;
    int n = children.length - 1;
    for (int i = 0; i < n; i++) {
      children[i+1].ang = (subType == SLOT_SPOKE)
        ? radians(180 + i * (360.0 / n))
        : radians(i * (360.0 / n));
    }
  }

  // Cache management
  void invalidateCache() {
    imgMasked = null; imgCacheSize = -1; imgCacheShape = -1;
  }

  void rebuildMask(int diameter) {
    if (img == null || !cropToShape) { imgMasked = null; return; }
    if (imgCacheSize == diameter && imgCacheShape == shapeType
        && imgMasked != null) return;
    imgCacheSize  = diameter;
    imgCacheShape = shapeType;

    int imgSize = (shapeType == SHAPE_DIAMOND) ? (int)(diameter / sqrt(2.0)) : diameter;
    int offset  = (diameter - imgSize) / 2;

    PGraphics imgG = createGraphics(diameter, diameter, JAVA2D);
    imgG.beginDraw(); imgG.clear();
    imgG.image(img, offset, offset, imgSize, imgSize);
    imgG.endDraw();

    PGraphics mask = createGraphics(diameter, diameter, JAVA2D);
    mask.beginDraw(); mask.background(0); mask.noStroke(); mask.fill(255);
    int cx = diameter/2, cy = diameter/2, r2 = diameter/2;
    if      (shapeType == SHAPE_CIRCLE)  mask.ellipse(cx, cy, diameter, diameter);
    else if (shapeType == SHAPE_RECT)    mask.rect(0, 0, diameter, diameter, (int)(r2*0.3));
    else { mask.beginShape();
           mask.vertex(cx,0); mask.vertex(diameter,cy);
           mask.vertex(cx,diameter); mask.vertex(0,cy);
           mask.endShape(CLOSE); }
    mask.endDraw();

    imgG.mask(mask);
    imgMasked = imgG;
  }
}

// ── Orbit radii (top-level frameworks) ───────────────────────────────────────
float spokeOrbitR    = 190;
float crossOrbitR    = 185;
float twoInnerOrbitR = 110;
float twoOuterOrbitR = 280;

// ── Node arrays ───────────────────────────────────────────────────────────────
NodeState[] spokeState;
NodeState[] crossState;
NodeState[] twoState;

// ── Image loading ─────────────────────────────────────────────────────────────
NodeState pendingImageNode = null;

void imageSelected(File f) {
  if (f == null || pendingImageNode == null) return;
  PImage loaded = loadImage(f.getAbsolutePath());
  if (loaded != null) { pendingImageNode.img = loaded; pendingImageNode.invalidateCache(); }
  pendingImageNode = null;
}

// ── Hub orbit adjustment ──────────────────────────────────────────────────────
void adjustHubOrbit(int frameId, int slot, float delta) {
  // slot >= 0 means the selected hub is a node's sub-diagram hub
  if (slot >= 0) {
    // find the owning NodeState and adjust its subOrbitR
    NodeState owner = findSlotOwner(frameId, slot);
    if (owner != null) owner.subOrbitR = max(20, owner.subOrbitR + delta);
  } else {
    switch (frameId) {
      case 0: spokeOrbitR    = max(60, spokeOrbitR    + delta); break;
      case 1: crossOrbitR    = max(60, crossOrbitR    + delta); break;
      case 2: twoInnerOrbitR = max(40, twoInnerOrbitR + delta); break;
    }
  }
}

// Find the NodeState that owns slot i in the given framework
NodeState findSlotOwner(int frameId, int slot) {
  if (frameId == 2 && twoState != null) {
    int idx = 1 + nInner + slot;
    if (idx < twoState.length) return twoState[idx];
  }
  return null;
}

// ── Init ──────────────────────────────────────────────────────────────────────
void initAllStates() {
  initSpokeState();
  initCrossState();
  initTwoState();
}

void initSpokeState() {
  int needed = nSpoke + 1;
  if (spokeState != null && spokeState.length == needed) return;
  spokeState = new NodeState[needed];
  spokeState[0] = new NodeState("center", 50, 0);
  for (int i = 0; i < nSpoke; i++) {
    float ang = radians(180 + i * (360.0 / nSpoke));
    spokeState[i+1] = new NodeState("Node " + (char)('A'+i%26), 55, ang);
  }
}

void initCrossState() {
  int needed = nCross + 1;
  if (crossState != null && crossState.length == needed) return;
  crossState = new NodeState[needed];
  crossState[0] = new NodeState("center", 60, 0);
  for (int i = 0; i < nCross; i++) {
    float ang  = radians(i * (360.0 / nCross));
    float rSat = min(58, (TWO_PI * 185 / nCross) * 0.36);
    crossState[i+1] = new NodeState("Node " + (char)('A'+i%26), rSat, ang);
  }
}

void initTwoState() {
  int needed = 1 + nInner + nOuter;
  if (twoState != null && twoState.length == needed) return;
  twoState = new NodeState[needed];
  twoState[0] = new NodeState("center", 52, 0);
  for (int i = 0; i < nInner; i++) {
    float ang = radians(i * (360.0 / nInner));
    twoState[1+i] = new NodeState("Node " + (char)('A'+i%26), 38, ang);
  }
  for (int i = 0; i < nOuter; i++) {
    float ang = radians(-45) + i * radians(360.0 / nOuter);
    twoState[1+nInner+i] = new NodeState("Outer " + (char)('A'+i%26), 55, ang);
  }
}
